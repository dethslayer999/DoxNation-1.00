Welcome To DoxNation Aka Little Brother Big Thanks
To Team Wicked They Helped Me Out Kinda With This
-----------------------------------------------------------------------------------------------
Installation:_

1. apt-get update
2. apt-get upgrade
3. apt-get install git
4. apt-get install python3
5. python3 -m pip install -r requirements.txt
6. python3 DoxNation 
7. Enjoy

Need Help Smoke Weed Every Day Skids, Nano
Is Out.